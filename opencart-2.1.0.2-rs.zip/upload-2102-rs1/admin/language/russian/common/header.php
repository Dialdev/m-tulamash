<?php
// Heading
$_['heading_title']        = 'Администрирование';

// Text
$_['text_order']           = 'Заказы';
$_['text_processing_status'] = 'Статусы заказов';
$_['text_order_status']    = 'Статусы заказов';
$_['text_complete_status'] = 'Завершено';
$_['text_customer']        = 'Клиенты';
$_['text_online']          = 'Клиенты Online';
$_['text_approval']        = 'Ожидают одобрения';
$_['text_product']         = 'Товары';
$_['text_stock']           = 'Нет в наличии';
$_['text_review']          = 'Отзывы';
$_['text_return']          = 'Возвраты';
$_['text_affiliate']       = 'Партнерская программа';
$_['text_store']           = 'Магазин';
$_['text_front']           = 'Магазин';
$_['text_help']            = 'Помощь';
$_['text_homepage']        = 'Сайт ';
$_['text_support']         = 'Форум';
$_['text_documentation']   = 'Документация';
$_['text_logout']          = 'Выход';

