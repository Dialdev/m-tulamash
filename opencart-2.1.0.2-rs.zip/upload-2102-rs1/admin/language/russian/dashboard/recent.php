<?php
// Heading
$_['heading_title']     = 'Последние заказы';

// Column
$_['column_order_id']   = '№';
$_['column_customer']   = 'Покупатель';
$_['column_status']     = 'Состояние';
$_['column_total']      = 'Сумма';
$_['column_date_added'] = 'Добавлено';
$_['column_action']     = 'Действие';

