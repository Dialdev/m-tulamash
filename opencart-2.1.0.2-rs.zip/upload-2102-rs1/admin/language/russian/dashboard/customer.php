<?php
// Heading
$_['heading_title'] = ' Клиентов';

// Text
$_['text_view'] = 'подробнее...';

